# API URLs
GEOCODING_API_URL = "https://maps.googleapis.com/maps/api/geocode/json"
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"
OPENCAGE_API_URL = "https://api.opencagedata.com/geocode/v1/json"
OPENCAGE_API_KEY = "your-opencage-api-key"
GOOGLE_API_KEY = "your-google-api-key"
GOOGLE_CX = "your-google-cx"
GOOGLE_SEARCH_URL = "https://www.googleapis.com/customsearch/v1"